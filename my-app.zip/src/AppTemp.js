import React from "react";
import Simulator from "./components/Simulator/Simulator.js";


export default function AppTemp(){
    return (
        <div>
            {/* <TempSemu /> */}
        </div>
    );
}