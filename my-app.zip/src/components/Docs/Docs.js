import React from 'react'

export default function Docs() {
  return (
    <div>
      Docs Page
    </div>
  )
}
