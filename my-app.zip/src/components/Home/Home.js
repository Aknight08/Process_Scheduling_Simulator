// Home.js

import React from 'react';
import image from "./one.png";


export default function Home() {
  return (
    <div>
        <img className="card-img-top img-fluid " src={image} alt="Title" />
        {/* <div
  style="background:./">
  <img src="your-icon-url">
</div> */}
      {/* <img src={image} className="img-fluid" alt="home image"/> Use the imported image */}
      {/* <div className="card ">
        <img className="card-img-top img-fluid" src={image} alt="Title" />
        <div className="card-body">
            <h4 className="card-title">Title</h4>
            <p className="card-text">fndskfn</p>
        </div> */}
      {/* </div> */}
      
    </div>
  );
}

