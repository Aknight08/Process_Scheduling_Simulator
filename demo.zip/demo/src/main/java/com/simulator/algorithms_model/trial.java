package com.simulator.algorithms_model;

public class trial {

}
